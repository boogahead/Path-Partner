package com.ssafy.pathpartner.travelgroup.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ssafy.pathpartner.travelgroup.dto.ChatDto;
import com.ssafy.pathpartner.travelgroup.service.ChatService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
public class ChatServiceTest {

    @Autowired
    private ChatService chatService;

    @Test
    public void testCreateChat() throws SQLException, JsonProcessingException {
        // Arrange
        ChatDto chatDto = new ChatDto();
        // Set properties on chatDto

        // Act
        boolean result = chatService.insertChat(chatDto);

        // Assert
        assertTrue(result);
    }

    // Additional test methods for other methods in ChatService
}