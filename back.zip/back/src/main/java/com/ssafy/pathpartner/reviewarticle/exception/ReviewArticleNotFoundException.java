package com.ssafy.pathpartner.reviewarticle.exception;

public class ReviewArticleNotFoundException extends RuntimeException {

  public ReviewArticleNotFoundException(String msg) {
    super(msg);
  }
}
