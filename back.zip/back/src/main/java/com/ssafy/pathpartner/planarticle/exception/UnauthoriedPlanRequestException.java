package com.ssafy.pathpartner.planarticle.exception;

public class UnauthoriedPlanRequestException extends RuntimeException{
  public UnauthoriedPlanRequestException(String msg) {
    super(msg);
  }
}
