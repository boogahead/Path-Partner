package com.ssafy.pathpartner.attraction.exception;

public class AttractionInfoNotFoundException extends RuntimeException {

  public AttractionInfoNotFoundException(String msg) {
    super(msg);
  }
}
