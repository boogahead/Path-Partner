package com.ssafy.pathpartner.travelgroup.exception;

public class MasterCanNotLeaveGroupException extends RuntimeException {

  public MasterCanNotLeaveGroupException(String msg) {
    super(msg);
  }
}
