package com.ssafy.pathpartner.reviewarticle.exception;

public class UnauthrizedReviewArticleRequestException extends RuntimeException {

  public UnauthrizedReviewArticleRequestException(String msg) {
    super(msg);
  }
}
