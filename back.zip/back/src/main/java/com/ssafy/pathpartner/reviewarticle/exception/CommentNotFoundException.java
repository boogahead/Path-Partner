package com.ssafy.pathpartner.reviewarticle.exception;

public class CommentNotFoundException extends RuntimeException {

  public CommentNotFoundException(String msg) {
    super(msg);
  }
}
