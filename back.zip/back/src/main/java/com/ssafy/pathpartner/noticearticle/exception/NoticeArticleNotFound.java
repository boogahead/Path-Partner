package com.ssafy.pathpartner.noticearticle.exception;

public class NoticeArticleNotFound extends RuntimeException{
  public NoticeArticleNotFound(String msg) {
    super(msg);
  }
}
