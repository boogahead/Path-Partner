package com.ssafy.pathpartner.reviewarticle.exception;

public class UnauthorizedCommentRequestException extends RuntimeException {

  public UnauthorizedCommentRequestException(String msg) {
    super(msg);
  }

}
