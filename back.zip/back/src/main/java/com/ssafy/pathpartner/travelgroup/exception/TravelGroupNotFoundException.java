package com.ssafy.pathpartner.travelgroup.exception;

public class TravelGroupNotFoundException extends RuntimeException{
  public TravelGroupNotFoundException(String msg) {
    super(msg);
  }
}
