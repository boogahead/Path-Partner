package com.ssafy.pathpartner.planarticle.exception;

public class PlanArticleNotFoundException extends RuntimeException{
  public PlanArticleNotFoundException(String msg) {
    super(msg);
  }

}
